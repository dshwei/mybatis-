package com.example.basefeigen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaseFeigenApplication {

    public static void main(String[] args) {
        SpringApplication.run(BaseFeigenApplication.class, args);
    }

}
