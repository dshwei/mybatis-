package com.example.basefeigen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseFeigenApplicationTests {

    @Test
    void contextLoads() {
    }

}
